const { load } = require('cheerio')
const fs = require('fs');
const path = require('path');
const getChampsData = require('../utils/getChampsData.js')
const Scrapper = require('../lib/Scrapper.js')

module.exports = async () => {
    //https://ddragon.leagueoflegends.com/cdn/13.14.1/data/en_US/champion.json

    const version_r = await fetch('https://ddragon.leagueoflegends.com/api/versions.json');
    const v_json = await version_r.json();

    let actual = v_json[0]

    console.log(`Getting champion data from patch ${actual}`)

    const request = await fetch(`https://ddragon.leagueoflegends.com/cdn/${actual}/data/en_US/champion.json`);

    const json = await request.json();

    const Champs = await getChampsData(json);

    let data = path.resolve(__dirname, '../../data/')
    if(!fs.existsSync(data)) fs.mkdirSync(data)
    
    console.log('Total champs: ' + Champs.length)
    fs.writeFileSync(path.resolve(data, './Champs.json'), JSON.stringify(Champs, null, 2))
    return;

};