const { load } = require('cheerio')
const fs = require('fs');
const path = require('path');
const getRunesData = require('../utils/getRunesData.js')
const getShardsData = require('../utils/getShardsData.js')
const Scrapper = require('../lib/Scrapper.js')

module.exports = async () => {

    const request = await Scrapper.prototype.get('https://leagueoflegends.fandom.com/wiki/Rune_(League_of_Legends)', {}, true, undefined, false);

    const $ = load(request);

    const [Champs, Shards] = await Promise.all([
        getRunesData($),
        getShardsData($)
    ])

    let data = path.resolve(__dirname, '../../data/')
    if(!fs.existsSync(data)) fs.mkdirSync(data)
    
    console.log('Total runes: ' + Champs.length)
    fs.writeFileSync(path.resolve(data, './Runes.json'), JSON.stringify(Champs, null, 2))

    console.log('Total shards: ' + Shards.length)
    fs.writeFileSync(path.resolve(data, './Shards.json'), JSON.stringify(Shards, null, 2))
    return;

};