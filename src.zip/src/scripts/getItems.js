const { load } = require('cheerio')
const getBoots = require('../utils/getBoots.js');
const getStarterItem = require('../utils/getStarterItem.js');
const getLegendaryItem = require('../utils/getLegendaryItem.js');
const fs = require('fs');
const path = require('path');
const Scrapper = require('../lib/Scrapper.js')

module.exports = async () => {

    const request = await Scrapper.prototype.get('https://leagueoflegends.fandom.com/wiki/List_of_items', {}, true, undefined, false);;

    const $ = load(request);

    const [StarterItems, Boots, LegendaryItems, MythicItems] = await Promise.all([
        getStarterItem($),
        getBoots($),
        getLegendaryItem($)
    ])

    console.log(Boots)

    let scales = []

    for(var item of StarterItems) {
        let iScales = item.scales;
        for(var c of iScales) {
            if(!scales.includes(c)) scales.push(c)
        }
    }

    for(var item of LegendaryItems) {
        let iScales = item.scales;
        for(var c of iScales) {
            if(!scales.includes(c)) scales.push(c)
        }
    }

    for(var item of MythicItems) {
        let iScales = item.scales;
        for(var c of iScales) {
            if(!scales.includes(c)) scales.push(c)
        }
    }

    let data = path.resolve(__dirname, '../../data/')
    if(!fs.existsSync(data)) fs.mkdirSync(data)
    fs.writeFileSync(path.resolve(data, './StarterItems.json'), JSON.stringify(StarterItems, null, 2))
    fs.writeFileSync(path.resolve(data, './Boots.json'), JSON.stringify(Boots, null, 2))
    fs.writeFileSync(path.resolve(data, './LegendaryItems.json'), JSON.stringify(LegendaryItems, null, 2))
    fs.writeFileSync(path.resolve(data, './Scales.json'), JSON.stringify(scales, null, 2))

};