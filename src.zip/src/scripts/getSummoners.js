const { load } = require('cheerio')
const getSummoners = require('../utils/getSummoners.js');
const fs = require('fs');
const path = require('path');
const Scrapper = require('../lib/Scrapper.js')

module.exports = async () => {

    const request = await Scrapper.prototype.get('https://leagueoflegends.fandom.com/wiki/Summoner_spell', {}, true, undefined, false);;

    const $ = load(request);

    const Summoners = await getSummoners($);

    let data = path.resolve(__dirname, '../../data/')
    if(!fs.existsSync(data)) fs.mkdirSync(data)
    fs.writeFileSync(path.resolve(data, './Summoners.json'), JSON.stringify(Summoners, null, 2))

};