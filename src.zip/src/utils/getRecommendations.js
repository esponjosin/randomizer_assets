const { load } = require('cheerio');
const util = require('util');

module.exports = async function getRecommendatios(champ) {

    let [skills, data] = await Promise.all([
        getSkills(champ.id),
        getRunes(champ.id)
    ])

    data.skills = skills

    return data;

}

async function getRunes(champId) {

    const Runes = require('../../data/Runes.json');

    let Roles = {
        'top': 'top',
        'jungle': 'jungle',
        'middle': 'mid',
        'bot': 'adc',
        'support': 'support'
    }

    let data = {}

    await Promise.all(Object.keys(Roles).map(role => (async function() {
        
        let response = await fetch(`https://u.gg/lol/champions/${champId}/runes-table?rank=overall&role=${role.toLowerCase()}`)
        let $ = load(await response.text());
        
        let primary = getPrimary($, Runes)
        let secondary = getSecondary($, Runes)

        data[Roles[role].toLowerCase()] = {
            runes: {
                primary: primary,
                secondary: secondary
            }
        }

    })()))

    return data

}

async function getSkills(champ) {

    let response = await fetch(`https://u.gg/lol/champions/${champ}/spells-abilities?rank=overall`)
    let $ = load(await response.text());

    let abilities = $('div.abilities > .grid-block-content > div:nth-child(1) > .skill-path > div.label > span').map(function() {
        return $(this).text()
    }).toArray()

    return abilities;

}

function getPrimary($, Runes) {

    let data = []

    let runes = $('.primary-runes-grid > div')

    for(var rune of runes) {

        rune = $(rune)
        let runeData = {}

        let runeName = rune.find('div.grid-block-header > .title > h2').text()
        runeData.name = runeName;
        let runeIndex = Runes.findIndex(x => x.name.toLowerCase() == runeName.toLowerCase())
        let image = Runes[runeIndex].image
        runeData.image = image;

        let keystones = rune.find('.grid-block-content > .grid-block-content-keystones > div').filter(function () {
            let keystone = $(this)
            let active = keystone.find('div:nth-child(1)').hasClass('grayscale')
            return !active
        }).map(function() {
            let keystone = $(this)
            let name = $(keystone.find('div:nth-child(1) > img')).attr('alt').split('Keystone')[1].trim()
            return name
        }).toArray()

        if(keystones.length > 0) data.push(runeData)

    }

    return data;


}

function getSecondary($, Runes) {

    let data = []

    let runes = $('.secondary-runes-grid > div')

    for(var rune of runes) {

        rune = $(rune)
        let runeData = {}

        let runeName = rune.find('div.grid-block-header > .title > h2').text()
        runeData.name = runeName;
        let runeIndex = Runes.findIndex(x => x.name.toLowerCase() == runeName.toLowerCase())
        let image = Runes[runeIndex].image
        runeData.image = image;

        let slots = rune.find('.grid-block-content > .grid-block-content-runes > div').filter(function () {
            let slot = $(this)
            let active = slot.find('div:nth-child(1)').hasClass('grayscale')
            return !active
        }).map(function() {
            let slot = $(this)
            let name = $(slot.find('div:nth-child(1) > img')).attr('alt').split('Rune')[1].trim()
            return name
        }).toArray()

        if(slots.length > 0) data.push(runeData)

    }

    return data;


}