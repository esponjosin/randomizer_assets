const fs = require('fs');
const path = require('path');

module.exports = async (file) => {
    
    console.log('Creating images from ' + file)
    let list = JSON.parse(fs.readFileSync(file, 'utf-8'));
    let data = path.resolve(__dirname, '../../data/')
    if(!fs.existsSync(data)) fs.mkdirSync(data)
    let imgPath = path.resolve(data, './img')
    if(!fs.existsSync(imgPath)) fs.mkdirSync(imgPath)

    let keys = Object.keys(list)
    
    for(var obj of keys.filter(x => Array.isArray(list[x]))) {
        await createImage(list[obj], imgPath)
    }
    
    for(var obj of keys.filter(x => typeof list[x] == 'object')) {
        await createImage(list[obj], imgPath)
    }

    fs.writeFileSync(file, JSON.stringify(list, null, 2))

    console.log('Images created of ' + file)

}

async function createImage(obj, imgPath) {
   
    let keys = Object.keys(obj)
    if(keys.some(k => typeof obj[k] == 'object')) {
        for(var key of keys) {
            await createImage(obj[key], imgPath)
        }
    }

    if(obj.name && obj.image) {
        let name = obj.name.split("'").join('_').split(' ').join('_').split(':').join('');
        console.log(`Saving image of: ${obj.name}`)
        if(!fs.existsSync(path.resolve(imgPath, `${name}.png`)) && !fs.existsSync(path.resolve(imgPath, `${name}.webp`))) {
            let img = await fetch(obj.image);
            let buffer = await img.arrayBuffer();
            buffer = await optimize(buffer)
            fs.writeFileSync(path.resolve(imgPath, `${name}.png`), Buffer.from(buffer))
            obj.image = `/data/img/${name}.png`
        } else if(fs.existsSync(path.resolve(imgPath, `${name}.png`))) {
            let buffer = fs.readFileSync(path.resolve(imgPath, `${name}.png`));
            buffer = await optimize(buffer);
            fs.unlinkSync(path.resolve(imgPath, `${name}.png`))
            fs.writeFileSync(path.resolve(imgPath, `${name}.webp`), Buffer.from(buffer))
            if(obj.name != `/data/img/${name}.webp`) obj.image = `/data/img/${name}.webp`
        } else if(fs.existsSync(path.resolve(imgPath, `${name}.webp`))) {
            if(obj.name != `/data/img/${name}.webp`) obj.image = `/data/img/${name}.webp`
        }
    }

}

async function optimize(buffer) {

    const imageminWebp = (await import('imagemin-webp')).default;

    let image = await imageminWebp({
        quality: 80
    })(Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer))

    return image;

}