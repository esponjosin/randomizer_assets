const getImage = require('./getImage.js');
const listFilter = require('./const.js')

module.exports = async function getBoots($) {
    
    const list = $(`dt:contains("Boots")`).parent().next().children().children();
    const Boots = [];

    for(var boot of list) {
        boot = $(boot);
        let text = boot.find('div').data('item');
        let image = boot.find('div > div > a > img').attr('src');
        let filter = /classic.{0,}5v5/ig.test(boot.find('div').data('modes'))
        if((
            text && typeof text == 'string') && 
            image && filter &&
            !listFilter.some(x => x.toLowerCase() == text.toLowerCase())
        ) Boots.push({
            name: text,
            image: image.split('latest')[0] + 'latest'
        }); else {
            console.log(text)
            console.log(`Failed:
\tName: ${!text && typeof text == 'string'}
\tImage: ${!image}
\tFilter: ${!filter}
\tInvalid Item: ${listFilter.some(x => x.toLowerCase() == text.toLowerCase())}`)
        }
    }

    return Boots;

}