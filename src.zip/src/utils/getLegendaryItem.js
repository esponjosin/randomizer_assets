const getImage = require('./getImage.js');
const listFilter = require('./const.js')
const { load } = require('cheerio');

module.exports = async function getLegendaryItem($) {
    
    const list = $(`dt:contains("Legendary items")`).parent().next().children().children();
    const Items = [];

    for(let boot of list) {
        boot = $(boot)
        let text = boot.find('div').data('item');
        let image = boot.find('div > div > a > img').attr('src');
        let filter = /classic.{0,}5v5/ig.test(boot.find('div').data('modes'))
        if(
            (text && typeof text == 'string') 
            && image 
            && filter
            && !listFilter.some(x => x.toLowerCase() == text.toLowerCase())
        ) {

            let data = {
                name: text,
                image: image.split('latest')[0] + 'latest'
            }
            
            let scales = await getTypes('https://leagueoflegends.fandom.com' + boot.find('div > div > a').attr('href'))

            if(scales && scales.length) data.scales = scales

            Items.push(data)

        } else {
            console.log(text)
            console.log(`Failed:
\tName: ${!text && typeof text == 'string'}
\tImage: ${!image}
\tFilter: ${!filter}
\tInvalid Item: ${listFilter.some(x => x.toLowerCase() == text.toLowerCase())}`)
        }
    }

    return Items;

}

async function getTypes(url) {

    let request = await fetch(url);
    let html = await request.text();
    let $ = load(html)

    try {
            let scales = $($('h2:contains("Menu")').get(0)).next().find('li')

        scales = scales.map(function () {
            return $(this).text();
        }).toArray()

        return scales
    } catch(e) 
    {
        return null
    }

}