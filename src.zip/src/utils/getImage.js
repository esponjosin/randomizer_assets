const { load } = require('cheerio')
const Scrapper = require('../lib/Scrapper.js')

module.exports = async function getImage(url, alt) {
    
    console.log(`https://leagueoflegends.fandom.com/${url}`)
    let request = await Scrapper.prototype.get(`https://leagueoflegends.fandom.com/${url}`);
    const $ = await load(request)

    let image = $(`img[alt="${alt}"]:not(.thumbborder)`).attr('src') ?? $(`#infobox-champion-container > aside > figure > a > img`).attr('src');

    return image

}