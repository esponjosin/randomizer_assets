const getImage = require('./getImage.js');
const listFilter = require('./const.js')

module.exports = async function getSummoners($) {
    
    const list = $(`span:contains("Standard summoner spells")`).parent().next().children().find('td');
    console.log(list)
    const Summoners = [];

    for(var sum of list) {
        sum = $(sum);
        let text = sum.find('div').data('spell');
        let image = sum.find('div > div > a > img').attr('src');
        if((
            text && typeof text == 'string') && 
            image 
            && !listFilter.some(x => x.toLowerCase() == text.toLowerCase())
        ) Summoners.push({
            name: text,
            image: image.split('latest')[0] + 'latest'
        })
    }

    return Summoners;

}