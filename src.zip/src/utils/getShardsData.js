const getImage = require('./getImage.js');

module.exports = async function getShardsData($) {
    
    const list = $('td > img');
    console.log(list.length)
    const Shards = {
        Offense: [],
        Flex: [],
        Defense: []
    };

    for(var shard of list) {
        let s = Shards.Offense.length < 3 ? 'Offense'
        : Shards.Flex.length < 3 ? 'Flex' : 'Defense';
        shard = $(shard)
        let name = shard.attr('alt').split('shard')[1].trim();
        let img = shard.attr('src').split('latest')[0] + 'latest';
        if(name && img) Shards[s].push({
            name,
            image: img
        })
    }

    return Shards

}