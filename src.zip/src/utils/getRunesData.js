const getImage = require('./getImage.js');

module.exports = async function getRunesData($) {
    
    const list = $('.rune-table > tbody > tr.runerow');
    console.log(list.length)
    const Runes = [];

    for(var rune of list) {

        rune = $(rune).next();

        const name = rune.find('th > a:nth-child(1)').attr('title')
        const image = rune.find('th > a:nth-child(1) > img').attr('src')?.split('latest')[0] + 'latest'

        const keystones = []
        let keystones_ = [
            rune.find('td:nth-child(2) > span.rune-icon'),
            ...rune.find('td:nth-child(2) > p > span.rune-icon')
        ]
        
        for(var keys of keystones_) {
            let keystone = $(keys)
            let n = keystone.data('rune')
            let img = keystone.find('a > img').attr('src')?.split('latest')[0] + 'latest'
            keystones.push({
                name: n,
                image: img
            })
        }

        let slot1 = []
        let slot1Data = [
            rune.find('td:nth-child(3) > span.rune-icon'),
            ...rune.find('td:nth-child(3) > p > span.rune-icon')
        ]
        
        for(var s of slot1Data) {
            let slot = $(s)
            let n = slot.data('rune')
            let img = slot.find('a > img').attr('src')?.split('latest')[0] + 'latest'
            slot1.push({
                name: n,
                image: img
            })
        }

        let slot2 = []
        let slot2Data = [
            rune.find('td:nth-child(4) > span.rune-icon'),
            ...rune.find('td:nth-child(4) > p > span.rune-icon')
        ]
        
        for(var s of slot2Data) {
            let slot = $(s)
            let n = slot.data('rune')
            let img = slot.find('a > img').attr('src')?.split('latest')[0] + 'latest'
            slot2.push({
                name: n,
                image: img
            })
        }

        let slot3 = []
        let slot3Data = [
            rune.find('td:nth-child(5) > span.rune-icon'),
            ...rune.find('td:nth-child(5) > p > span.rune-icon')
        ]
        
        for(var s of slot3Data) {
            let slot = $(s)
            let n = slot.data('rune')
            let img = slot.find('a > img').attr('src')?.split('latest')[0] + 'latest'
            slot3.push({
                name: n,
                image: img
            })
        }

        if(name && image) await Runes.push({
            name: name,
            image: image,
            keystones,
            slot1,
            slot2,
            slot3
        })

    }

    return Runes;

}