const getImage = require('./getImage.js');
const { load } = require('cheerio');
const getRecommendations = require('./getRecommendations.js');

function chunk(arr, chunkSize) {
    var R = [];
    for (var i = 0; i < arr.length; i += chunkSize)
      R.push(arr.slice(i, i + chunkSize));
    return R;
}

module.exports = async function getChampsData(obj) {
    
    const list = Object.keys(obj.data);
    console.log(list.length)
    const Champs = [];

    await Promise.all(chunk(list, list.length / 3).map((list2, index) => (async function champ() {


        for(var i=0; i < list2.length; i++) {
            
            let champ = obj.data[list2[i]]
            let name = toUpper(champ.name);
            let title = toUpper(champ.title);
            let tags = champ.tags
            let [splash, abilities, recommendations, scales] = await Promise.all([
                getSplash(champ.id),
                getSpells(champ),
                getRecommendations(champ),
                calculateScales(champ)
            ])

            let data = {
                name: name,
                title: title,
                tags: tags,
                image: splash
            }

            data.abilities = abilities;
            if(recommendations) data.recommendations = recommendations;

            data.scale = scales

            Champs.push(data)

            console.log(`Champs ${Champs.length}/${list.length}`)
        }

    })()))

    return Champs;

}

async function calculateScales(champ) {

    let response = await fetch(`https://ddragon.leagueoflegends.com/cdn/${champ.version}/data/en_US/champion/${champ.id}.json`)
    let json = await response.json();
    champ = json.data[champ.id]
    let scale = champ.info.attack + champ.info.defense + champ.info.magic;
    let first = [
        { type: 'attack', amount: Math.round((champ.info.attack / scale) * 100) },
        { type: 'defense', amount: Math.round((champ.info.defense / scale) * 100) },
        { type: 'magic', amount: Math.round((champ.info.magic / scale) * 100) }
    ].sort((a,b)=> b.amount-a.amount).filter(x => !isNaN(x.amount))

    if(first.length) return first[0].type;
    return calculatePerSpell(champ.spells)

}

async function getSpells(champ) {

    let version = champ.version;
    let response = await fetch(`https://ddragon.leagueoflegends.com/cdn/${version}/data/en_US/champion/${champ.id}.json`)
    let json = await response.json();
    champ = json.data[champ.id]

    //https://ddragon.leagueoflegends.com/cdn/13.14.1/img/spell/AkaliQ.png

    let data = {}

    for(var i=0; i < 3; i++) {

        spell = champ.spells[i]

        let name = i==0? 'Q' : i==1 ? 'W' : 'E'

        let image = await getSpell(`https://ddragon.leagueoflegends.com/cdn/${version}/img/spell/${spell.image.full}`)

        data[name] = {
            image: image,
            name: `${champ.id}_${name}`,
            alias: spell.name
        }

    }

    return data;

}

async function getSpell(spell) {

    let first = await fetch(spell)
    if(first.ok) {

        if(first.headers.get('Content-Type').startsWith('image')) return spell

    }
}

function calculatePerSpell(spells) {

    let ap = 0;
    let ad = 0;
    let mHealth = 0;
    let defense = 0;
    for(var spell of spells) {

        let apCount = spell.description.match(/(magicDamage|magic\ damage)/igm)
        if(apCount == null) apCount = spell.tooltip.match(/(magicDamage|magic\ damage)/igm)
        ap += apCount == null ? 0 : apCount.length

        let adCount = spell.description.match(/(physicalDamage|physical\ damage)/igm)
        if(adCount == null) adCount = spell.tooltip.match(/(physicalDamage|physical\ damage)/igm)
        ad += adCount == null ? 0 : adCount.length

        let mHealthCount = spell.description.match(/((^max.{0,}health))/igm)
        if(mHealthCount == null) mHealthCount = spell.tooltip.match(/((^max.{0,}health))/igm)
        mHealth += mHealthCount == null ? 0 : mHealthCount.length * 10

        let defenseCount = spell.description.match(/(scaleArmor|scaleMR|(^scale.{0,}mr)|(^scale.{0,}armor))/igm)
        if(defenseCount == null) defenseCount = spell.tooltip.match(/(scaleArmor|scaleMR|(^scale.{0,}mr)|(^scale.{0,}armor))/igm)
        defense += defenseCount == null ? 0 : defenseCount.length * 10

    }

    return (ap > ad && ap > mHealth && ap > defense) ? 'magic' : 
    (ad > ap && ad > mHealth && ad > defense) ? 'attack' : 
    (mHealth > ap && mHealth > ad && mHealth > defense) ? 'health' : 'defense'

}

async function getSplash(name) {

    let url = `https://ddragon.leagueoflegends.com/cdn/img/champion/loading/${name}`

    let first = await fetch(url + '_0.jpg')
    if(first.ok) {

        if(first.headers.get('Content-Type').startsWith('image')) return url + '_0.jpg'

    }

    let second = await fetch(url + '_0.png')
    if(second.ok) {

        if(second.headers.get('Content-Type').startsWith('image')) return url + '_0.png'

    }

    let three = await fetch(url + '.jpg')
    if(three.ok) {

        if(three.headers.get('Content-Type').startsWith('image')) return url + '.jpg'

    }

    let four = await fetch(url + '.png')
    if(four.ok) {

        if(four.headers.get('Content-Type').startsWith('image')) return url + '.png'

    }

}

function toUpper(str) {
    return str
    .toLowerCase()
    .split(' ')
    .map(function(word) {
       return word[0].toUpperCase() + word.substr(1);
    })
    .join(' ');
}