const originalEmit = process.emit;
process.emit = function (name, data, ...args) {
  if (
    name === `warning` &&
    typeof data === `object` &&
    data.name === `ExperimentalWarning` 
    //if you want to only stop certain messages, test for the message here:
    //&& data.message.includes(`Fetch API`)
  ) {
    return false;
  }
  return originalEmit.apply(process, arguments);
};

const getItems = require('./scripts/getItems.js');
const getRunes = require('./scripts/getRunes.js');
const getChamps = require('./scripts/getChamps.js');
const createImages = require('./utils/createImages.js')
const path = require('path');
const fs = require('fs');
const getSummoners = require('./scripts/getSummoners.js');

(async () => {

    let start = Date.now();
	/*console.log('Getting Runes...');
    await getRunes();
    console.log(`Getting runes finished (took ${Date.now() - start})`);*/
    
    async function items() {
      start = Date.now();
      console.log('Getting Items...');
      await getItems();
      console.log(`Getting items finished (took ${Date.now() - start})`); 
    }

    async function champs() {
      start = Date.now();
      console.log('Getting Champs...')
      await getChamps();
      console.log(`Getting champs finished (took ${Date.now() - start})`);
    }
    
    async function summoners() {
      start = Date.now();
      console.log('Getting Summoners...')
      await getSummoners();
      console.log(`Getting summoners finished (took ${Date.now() - start})`);
    }

    await items()
    await champs()
    await summoners()

    let data = path.resolve(__dirname, '../data');

    /*let list = fs.readdirSync(data)
    for(var item of list.filter(l => fs.statSync(path.resolve(data, l)).isFile())) {
      await createImages(path.resolve(data, item))
    }*/

    process.exit()

})();